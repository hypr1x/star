import React from "react";
import Link from "next/link";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
const Nav = () => {
  return (
    <div className="flex px-40 py-5 align-bottom justify-between">
      <Link href="/" legacyBehavior passHref>
        <p className="font-black">hyprgg</p>
      </Link>
      <NavigationMenu>
        <NavigationMenuList>
          <NavigationMenuItem>
            <NavigationMenuTrigger>Getting Started</NavigationMenuTrigger>
            <NavigationMenuContent>
              <ul className="grid gap-3 p-6 md:w-[400px] lg:w-[500px] lg:grid-cols-[.75fr_1fr]">
                <li className="row-span-3">
                  <NavigationMenuLink asChild>
                    <a
                      className="flex h-full w-full select-none flex-col justify-end rounded-md bg-gradient-to-b from-muted/50 to-muted p-6 no-underline outline-none focus:shadow-md"
                      href="/"
                    >
                      <div className="mb-2 mt-4 text-lg font-bold">hypr.gg</div>
                      <p className="text-sm leading-tight text-muted-foreground">
                        Best way to improve in Fortnite and 1v1 good players. It
                        is fun, easy to handle, and completelty free to use.
                      </p>
                    </a>
                  </NavigationMenuLink>
                </li>
                <ListItem href="/signup" title="Create an account">
                  Log into or create a new hypr.gg account to use it in 1v1's.
                </ListItem>
                <ListItem href="/create-match" title="Create a game">
                  Pick a gamemode, a team size, and a server to play on.
                </ListItem>
                <ListItem href="" title="Submit a win">
                  Each win/loss affects your win percentage and record.
                </ListItem>
              </ul>
            </NavigationMenuContent>
          </NavigationMenuItem>
          <NavigationMenuItem>
            <Link href="/leaderboards" legacyBehavior passHref>
              <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                Leaderboards
              </NavigationMenuLink>
            </Link>
          </NavigationMenuItem>
          <NavigationMenuItem>
            <AlertDialog>
              <AlertDialogTrigger>
                {" "}
                <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                  Login
                </NavigationMenuLink>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Login or Signup</AlertDialogTitle>
                  <AlertDialogDescription>
                    An account is required to create matches or join others.
                  </AlertDialogDescription>
                  <Tabs defaultValue="CreateAccount">
                    <TabsList className="grid w-full grid-cols-2 mt-3">
                      <TabsTrigger value="CreateAccount">
                        Create Account
                      </TabsTrigger>
                      <TabsTrigger value="login">Login</TabsTrigger>
                    </TabsList>
                    <TabsContent value="CreateAccount">
                      <Card>
                        <CardHeader>
                          <CardTitle>Create Account</CardTitle>
                          <CardDescription>
                            Make a new account here. Click create when
                            you're done.
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-2">
                          <div className="space-y-1">
                            <Label htmlFor="username">Username</Label>
                            <Input id="username" />
                          </div>
                          <div className="space-y-1">
                            <Label htmlFor="password">Password</Label>
                            <Input id="password" type="password" />
                          </div>
                          <div className="space-y-1">
                            <Label htmlFor="password2">Confirm Passowrd</Label>
                            <Input id="password2" type="password" />
                          </div>
                        </CardContent>
                        <CardFooter>
                          <Button className="mr-2">Create Account</Button>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                        </CardFooter>
                      </Card>
                    </TabsContent>
                    <TabsContent value="login">
                      <Card>
                        <CardHeader>
                          <CardTitle>Login to account</CardTitle>
                          <CardDescription>
                            Change your password here. After saving, you'll be
                            logged out.
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-2">
                          <div className="space-y-1">
                            <Label htmlFor="current">Current password</Label>
                            <Input id="current" type="password" />
                          </div>
                          <div className="space-y-1">
                            <Label htmlFor="new">New password</Label>
                            <Input id="new" type="password" />
                          </div>
                        </CardContent>
                        <CardFooter>
                          <Button className="mr-2">Save changes</Button>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                        </CardFooter>
                      </Card>
                    </TabsContent>
                  </Tabs>
                </AlertDialogHeader>
              </AlertDialogContent>
            </AlertDialog>
          </NavigationMenuItem>
          <NavigationMenuItem>
            <NavigationMenuLink className={navigationMenuTriggerStyle()}>
              Sign Up
            </NavigationMenuLink>
          </NavigationMenuItem>
        </NavigationMenuList>
      </NavigationMenu>
    </div>
  );
};
const ListItem = React.forwardRef(
  ({ className, title, children, ...props }, ref) => {
    return (
      <li>
        <NavigationMenuLink asChild>
          <a
            ref={ref}
            className={cn(
              "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
              className
            )}
            {...props}
          >
            <div className="text-sm font-medium leading-none">{title}</div>
            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
              {children}
            </p>
          </a>
        </NavigationMenuLink>
      </li>
    );
  }
);
ListItem.displayName = "ListItem";

export default Nav;
