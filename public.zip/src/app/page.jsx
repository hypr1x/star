import { Button } from "@/components/ui/button";
export default function Home() {
  return (
    <main className="px-40 py-20">
      <h1 className="text-4xl font-extrabold">Put your skills to the test.</h1>
      <p className="my-4">
        Play competitive creative matches against good players to level up your
        skills.
      </p>
      <Button variant="default" className="mr-2">
        Get Started
      </Button>
      <Button variant="secondary">Find Match</Button>
    </main>
  );
}
