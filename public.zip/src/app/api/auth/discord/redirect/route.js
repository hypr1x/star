import url from "url";
import axios from "axios";

export async function GET(req) {
  let code = req.url.split("=")[1];
  if (code != "") {
    const formData = new url.URLSearchParams({
      grant_type: "authorization_code",
      code: code,
      redirect_uri: "http://localhost:3000/api/auth/discord/redirect",
    });
    // try {
      const output = await axios.post(
        "https://discord.com/v10/oauth2/token",
        formData,
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          auth: {
            username: "1263053466125729814",
            password: "aL6zzMTJBNysp526R3qcSnkmCBFNAvTN",
          },
        }
      );
      console.log(output);
    // } catch {}

    return new Response(code);
  }
}

// export { handler as GET };
